"""
core/forms.py
Ro'yxatdan o'tish, kirish, fayl yuklash va sharh qoldirish uchun formalar.
"""

import io
import random
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.files.base import ContentFile
from django.utils import timezone
from django.utils.text import slugify

from .models import CustomUser, Resource, Review
from .file_utils import sniff_file_type


INPUT_CLASSES = (
    "w-full rounded-xl border border-gray-300 dark:border-gray-700 "
    "bg-white/70 dark:bg-gray-900/70 px-4 py-3 backdrop-blur-sm "
    "focus:ring-2 focus:ring-indigo-500 focus:outline-none"
)


class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    telegram_id = forms.CharField(
        required=False,
        help_text="Ixtiyoriy: Telegram ID'ingizni kiriting yoki keyinroq botdan OTP orqali ulang."
    )

    class Meta:
        model = CustomUser
        fields = ["username", "email", "password1", "password2"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({"class": INPUT_CLASSES})

    def clean_telegram_id(self):
        tg_id = self.cleaned_data.get("telegram_id")
        if tg_id:
            if not tg_id.isdigit():
                raise forms.ValidationError("Telegram ID faqat raqamlardan iborat bo'lishi kerak.")
            if CustomUser.objects.filter(telegram_id=tg_id).exists():
                raise forms.ValidationError("Bu Telegram ID allaqachon boshqa hisobga ulangan.")
        return tg_id

    def save(self, commit=True):
        user = super().save(commit=False)
        tg_id = self.cleaned_data.get("telegram_id")
        if tg_id:
            user.telegram_id = int(tg_id)
            user.is_telegram_linked = True
        if commit:
            user.save()
        return user


class LoginForm(forms.Form):
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={"class": INPUT_CLASSES, "placeholder": "Login"})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={"class": INPUT_CLASSES, "placeholder": "Parol"})
    )


class TelegramLinkForm(forms.Form):
    """Web-saytda mavjud foydalanuvchi hisobini Telegram bilan OTP orqali bog'lash uchun."""
    otp_code = forms.CharField(max_length=6, min_length=6)

    def clean_otp_code(self):
        code = self.cleaned_data["otp_code"]
        if not code.isdigit():
            raise forms.ValidationError("OTP kod faqat raqamlardan iborat bo'lishi kerak.")
        return code

    @staticmethod
    def generate_otp(user: CustomUser) -> str:
        code = str(random.randint(100000, 999999))
        user.otp_code = code
        user.otp_created_at = timezone.now()
        user.save(update_fields=["otp_code", "otp_created_at"])
        return code


class ResourceUploadForm(forms.ModelForm):
    class Meta:
        model = Resource
        fields = ["title", "description", "category", "file"]
        widgets = {
            "title": forms.TextInput(attrs={
                "class": "w-full rounded-xl border border-gray-300 dark:border-gray-700 "
                         "bg-white/70 dark:bg-gray-900/70 px-4 py-3 backdrop-blur-sm "
                         "focus:ring-2 focus:ring-indigo-500 focus:outline-none",
                "placeholder": "Masalan: Matematik Analiz I-qism konspekti",
            }),
            "description": forms.Textarea(attrs={
                "class": "w-full rounded-xl border border-gray-300 dark:border-gray-700 "
                         "bg-white/70 dark:bg-gray-900/70 px-4 py-3 backdrop-blur-sm "
                         "focus:ring-2 focus:ring-indigo-500 focus:outline-none",
                "rows": 4,
                "placeholder": "Material haqida qisqacha ma'lumot... (majburiy)",
            }),
            "category": forms.Select(attrs={
                "class": "w-full rounded-xl border border-gray-300 dark:border-gray-700 "
                         "bg-white/70 dark:bg-gray-900/70 px-4 py-3 backdrop-blur-sm",
            }),
            "file": forms.ClearableFileInput(attrs={
                "class": "w-full rounded-xl border-2 border-dashed border-indigo-400 "
                         "px-4 py-6 cursor-pointer",
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Modelda ba'zi maydonlar (description, file) admin panel uchun
        # ixtiyoriy (blank=True) qilib belgilangan, lekin ODDIY FOYDALANUVCHI
        # yuklash formasida hech biri tashlab ketilmasligi kerak.
        self.fields["title"].required = True
        self.fields["description"].required = True
        self.fields["category"].required = True
        self.fields["file"].required = True

    def save(self, commit=True, user=None):
        resource = super().save(commit=False)
        resource.uploaded_by = user
        resource.uploaded_via = "web"
        base_slug = slugify(resource.title)[:250] or "resource"
        slug = base_slug
        counter = 1
        while Resource.objects.filter(slug=slug).exists():
            slug = f"{base_slug}-{counter}"
            counter += 1
        resource.slug = slug

        if resource.file:
            resource.file_size_kb = resource.file.size // 1024
            ext_from_name = resource.file.name.split(".")[-1].lower()
            resource.file.seek(0)
            head = resource.file.read()
            resource.file.seek(0)  # o'qishdan keyin boshiga qaytaramiz — saqlash uchun kerak
            resource.file_type = sniff_file_type(head, fallback_ext=ext_from_name)

        if commit:
            resource.save()
            if resource.file_type == "pdf":
                generate_pdf_preview(resource)
        return resource


DEMO_PREVIEW_PAGES = 5  # yuklab olmasdan ko'rish uchun ochiladigan sahifalar soni


def generate_pdf_preview(resource: Resource) -> bool:
    """
    PDF materialning birinchi DEMO_PREVIEW_PAGES sahifasidan iborat kichik
    "demo" fayl yaratadi. Muvaffaqiyatli bo'lsa True, aks holda False qaytaradi
    (masalan, fayl haqiqatda PDF bo'lmasa yoki buzilgan bo'lsa).
    """
    try:
        from pypdf import PdfReader, PdfWriter
    except ImportError:
        return False

    try:
        resource.file.open("rb")
        data = resource.file.read()

        if not data.startswith(b"%PDF"):
            # Fayl kengaytmasi "pdf" bo'lsa-da, haqiqiy mazmuni PDF emas
            return False

        reader = PdfReader(io.BytesIO(data))
        writer = PdfWriter()

        page_count = min(DEMO_PREVIEW_PAGES, len(reader.pages))
        for i in range(page_count):
            writer.add_page(reader.pages[i])

        buffer = io.BytesIO()
        writer.write(buffer)
        buffer.seek(0)

        resource.preview_file.save(
            f"preview_{resource.slug}.pdf", ContentFile(buffer.read()), save=True
        )
        return True
    except Exception:
        # PDF buzilgan yoki himoyalangan bo'lsa, demo-previewsiz qoldiramiz —
        # foydalanuvchi baribir to'liq faylni yuklab ola oladi.
        return False
    finally:
        resource.file.close()


class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ["rating", "comment"]
        widgets = {
            "rating": forms.RadioSelect(),
            "comment": forms.Textarea(attrs={
                "class": "w-full rounded-xl border border-gray-300 dark:border-gray-700 "
                         "bg-white/70 dark:bg-gray-900/70 px-4 py-3",
                "rows": 3,
                "placeholder": "Fikringizni yozing...",
            }),
        }


class AvatarUploadForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ["avatar"]
        widgets = {
            "avatar": forms.ClearableFileInput(attrs={
                "class": "hidden", "id": "avatar-input", "accept": "image/*",
            }),
        }


class ProfileEditForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ["avatar", "bio"]
        widgets = {
            "avatar": forms.ClearableFileInput(attrs={
                "class": "hidden", "id": "avatar-input", "accept": "image/*",
            }),
            "bio": forms.Textarea(attrs={
                "class": INPUT_CLASSES, "rows": 3,
                "placeholder": "O'zingiz haqingizda qisqacha...",
            }),
        }


class SearchForm(forms.Form):
    q = forms.CharField(required=False, max_length=200)
    category = forms.CharField(required=False)
    sort = forms.ChoiceField(
        required=False,
        choices=[
            ("new", "Yangi qo'shilganlar"),
            ("popular", "Eng ko'p yuklanganlar"),
            ("rating", "Eng yuqori baholanganlar"),
        ],
    )
