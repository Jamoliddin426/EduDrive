"""
core/management/commands/regenerate_previews.py

Ishlatish:
    python manage.py regenerate_previews

Ikki vazifani bajaradi:
1. Har bir materialning HAQIQIY fayl turini (magic number orqali) tekshiradi
   va agar bazadagi file_type noto'g'ri bo'lsa (masalan "pdf" deb yozilgan,
   lekin aslida .docx bo'lsa) — avtomatik tuzatadi.
2. Haqiqiy PDF materiallar uchun demo-preview faylni (DEMO_PREVIEW_PAGES
   sozlamasiga mos) qaytadan generatsiya qiladi.
"""

from django.core.management.base import BaseCommand
from core.models import Resource
from core.forms import generate_pdf_preview
from core.file_utils import sniff_file_type


class Command(BaseCommand):
    help = "Fayl turlarini tekshiradi/tuzatadi va PDF materiallar uchun demo-preview generatsiya qiladi."

    def handle(self, *args, **options):
        resources = Resource.objects.exclude(file="")
        total = resources.count()

        if total == 0:
            self.stdout.write(self.style.WARNING("Fayli bor materiallar topilmadi."))
            return

        fixed_type, generated, failed = 0, 0, 0

        for resource in resources:
            try:
                resource.file.open("rb")
                data = resource.file.read()
            finally:
                resource.file.close()

            real_type = sniff_file_type(data, fallback_ext=resource.file_type)
            if real_type and real_type != resource.file_type:
                self.stdout.write(self.style.WARNING(
                    f"  \u26a0 {resource.title}: fayl turi '{resource.file_type}' -> "
                    f"'{real_type}' ga tuzatildi (haqiqiy mazmuniga qarab)"
                ))
                resource.file_type = real_type
                resource.save(update_fields=["file_type"])
                fixed_type += 1

            if resource.file_type == "pdf":
                if generate_pdf_preview(resource):
                    generated += 1
                    self.stdout.write(f"  \u2705 {resource.title}")
                else:
                    failed += 1
                    self.stdout.write(self.style.ERROR(
                        f"  \u274c {resource.title}: demo yaratilmadi (fayl buzilgan yoki himoyalangan)"
                    ))

        self.stdout.write(self.style.SUCCESS(
            f"\nTayyor! {generated} ta PDF demo yangilandi, "
            f"{fixed_type} ta fayl turi tuzatildi, {failed} ta xato."
        ))
